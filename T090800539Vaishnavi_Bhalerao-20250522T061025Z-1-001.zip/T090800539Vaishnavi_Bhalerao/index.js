// Player 1
var randomNumber1 = Math.floor(Math.random() * 6) + 1;
var randomDiceImage1 = "dice" + randomNumber1 + ".png";
var randomImageSource1 = "images/" + randomDiceImage1;
document.querySelectorAll("img")[0].setAttribute("src", randomImageSource1);

// Player 2
var randomNumber2 = Math.floor(Math.random() * 6) + 1;
var randomDiceImage2 = "dice" + randomNumber2 + ".png";
var randomImageSource2 = "images/" + randomDiceImage2;
document.querySelectorAll("img")[1].setAttribute("src", randomImageSource2);

// Player 3
var randomNumber3 = Math.floor(Math.random() * 6) + 1;
var randomDiceImage3 = "dice" + randomNumber3 + ".png";
var randomImageSource3 = "images/" + randomDiceImage3;
document.querySelectorAll("img")[2].setAttribute("src", randomImageSource3);

// Determine the winner
if (randomNumber1 > randomNumber2 && randomNumber1 > randomNumber3) {
  document.querySelector("h1").innerHTML = "🚩 Player 1 Wins!";
}
else if (randomNumber2 > randomNumber1 && randomNumber2 > randomNumber3) {
  document.querySelector("h1").innerHTML = "🚩 Player 2 Wins!";
}
else if (randomNumber3 > randomNumber1 && randomNumber3 > randomNumber2) {
  document.querySelector("h1").innerHTML = "🚩 Player 3 Wins!";
}
else {
  document.querySelector("h1").innerHTML = "It's a Draw!";
}
